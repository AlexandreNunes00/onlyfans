
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const ADMIN_EMAIL = "alexandrenunes9292@gmail.com";
const API_URL = "http://localhost:4000";

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState("");
  const [userType, setUserType] = useState("viewer");
  const [redirectToCreate, setRedirectToCreate] = useState(false);
  const [profileName, setProfileName] = useState("");
  const [profilePic, setProfilePic] = useState("");
  const [bio, setBio] = useState("");
  const [welcomeVideo, setWelcomeVideo] = useState("");
  const [paymentLink, setPaymentLink] = useState("");
  const [media, setMedia] = useState([]);

  const fetchProfile = async (email) => {
    const res = await fetch(\`\${API_URL}/profile/\${email}\`);
    const data = await res.json();
    if (data) {
      setProfileName(data.name);
      setProfilePic(data.profilePic);
      setMedia(data.media);
    }
  };

  const handleLogin = () => {
    if (email === ADMIN_EMAIL) {
      setUserType("creator");
      setRedirectToCreate(true);  // Redireciona para criação de conta do criador
    } else {
      setUserType("viewer");
      setIsLoggedIn(true);  // Para visualizadores, apenas entra
    }
  };

  const handleCreateCreatorAccount = async () => {
    // Envia os dados para o servidor para salvar as informações do criador
    await fetch(\`\${API_URL}/createAccount\`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email,
        profileName,
        profilePic,
        bio,
        welcomeVideo,
        paymentLink,
      }),
    });
  };

  const handleMediaUpload = async (e) => {
    const files = e.target.files;
    if (files.length === 0) return;

    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append("file", files[i]);
    }

    const res = await fetch(\`\${API_URL}/upload/\${email}\`, {
      method: "POST",
      body: formData,
    });

    const data = await res.json();
    if (data.filePaths) {
      setMedia([...media, ...data.filePaths.map((path) => API_URL + path)]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">MyFans</h1>
        {isLoggedIn ? (
          <Button onClick={() => setIsLoggedIn(false)}>Sair</Button>
        ) : (
          <div className="space-x-2">
            <Input
              type="email"
              placeholder="Seu e-mail"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-64"
            />
            <Button onClick={handleLogin}>Entrar</Button>
          </div>
        )}
      </header>

      {redirectToCreate && userType === "creator" && (
        <section className="bg-white p-6 rounded-lg shadow mb-6">
          <h2 className="text-xl font-semibold mb-4">Criação de Conta - Criador</h2>

          <Label className="block mb-1">Nome do Criador:</Label>
          <Input
            onChange={(e) => setProfileName(e.target.value)}
            className="mb-4"
          />

          <Label className="block mb-1">Foto de Perfil (URL):</Label>
          <Input
            type="url"
            onChange={(e) => setProfilePic(e.target.value)}
            className="mb-4"
          />

          <Label className="block mb-1">Bio:</Label>
          <Input
            onChange={(e) => setBio(e.target.value)}
            className="mb-4"
          />

          <Label className="block mb-1">Vídeo de Boas-Vindas (URL):</Label>
          <Input
            type="url"
            onChange={(e) => setWelcomeVideo(e.target.value)}
            className="mb-4"
          />

          <Label className="block mb-1">Link de Pagamento (ex: PayPal ou outro):</Label>
          <Input
            type="url"
            onChange={(e) => setPaymentLink(e.target.value)}
            className="mb-4"
          />

          <Button
            onClick={handleCreateCreatorAccount}
            className="mt-4"
          >
            Criar Conta de Criador
          </Button>
        </section>
      )}

      <main className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {media.map((url, index) => (
          <Card key={index} className="shadow-lg">
            <CardContent className="p-4">
              {url.includes(".mp4") ? (
                <video controls src={url} className="rounded-xl mb-4 w-full" />
              ) : (
                <img
                  src={url}
                  alt={`Conteúdo ${index + 1}`}
                  className="rounded-xl mb-4"
                />
              )}
              <h2 className="text-xl font-semibold">Criador: @{profileName}</h2>
              <p className="text-sm text-gray-600 mt-2">
                Conteúdo exclusivo para assinantes.
              </p>
              <Button className="mt-4 w-full">Assinar por R$19,90</Button>
            </CardContent>
          </Card>
        ))}
      </main>
    </div>
  );
}
